
function myFunction() {

    document.getElementById("form").reset();
    
  }